INSERT IGNORE INTO `mesh_descriptors` (`mesh_id`, `descriptor_name`, `scope_note`, `descriptor_class`, `dataset_year`) VALUES
('D014533',	'Uridine Diphosphate Glucose Dehydrogenase',	'An enzyme that catalyzes the oxidation of UDPglucose to UDPglucuronate in the presence of NAD+. EC 1.1.1.22.',	'1',	2026);
