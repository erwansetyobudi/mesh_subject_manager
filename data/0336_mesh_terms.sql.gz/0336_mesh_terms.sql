INSERT IGNORE INTO `mesh_terms` (`id`, `mesh_id`, `term`) VALUES
(199473,	'D015194',	'Culture Diffusion Chambers'),
(199474,	'D015194',	'Semi-Permeable Chambers'),
(199475,	'D015194',	'Chamber, Semi-Permeable'),
(199476,	'D015194',	'Chambers, Semi-Permeable'),
(199477,	'D015194',	'Semi-Permeable Chamber'),
(199478,	'D015194',	'Semi Permeable Chambers');
